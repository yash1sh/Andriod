package com.example.miniproject;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.SparseArray;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.vision.Frame;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.IOException;

public class Main_Page extends AppCompatActivity {
    Button Capure;
    TextView textView;
    private static final int REQUEST_CAMERA_CODE =100;
    Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Capure=(Button)findViewById(R.id.takepic);
        textView=(TextView)findViewById(R.id.txttxt);

        if(ContextCompat.checkSelfPermission(Main_Page.this, Manifest.permission.CAMERA)!= PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(Main_Page.this,new String[]{
                    Manifest.permission.CAMERA
            },REQUEST_CAMERA_CODE);
        }

        Capure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CropImage.activity().setGuidelines(CropImageView.Guidelines.ON).start(Main_Page.this);

            }
        });
        //TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE
        {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if(resultCode == RESULT_ON)
            {
                Uri resultUri = result.getUri();
                try {
                    bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(),resultUri);

                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }
    }
    private void getTextFromTmage(Bitmap bitmap)
    {
        TextRecognizer recognizer= new TextRecognizerOptions.Builder(Main_Page.this).build();
        if(recognizer.isOperational())
        {
            Toast.makeText(Main_Page.this,"Error",Toast.LENGTH_SHORT).show();
        }
        else{
            Frame frame= new Frame.Builder().setBitmap(bitmap).build();
            SparseArray<Text.TextBlock> textBlockSparseAray=recognizer.detect(frame);
            StringBuilder stringBuilder = new StringBuilder();
            for(int i=0;i<textBlockSparseAray.size();i++)
            {
                Text.TextBlock textBlock=textBlockSparseAray.valueAt(i);
                stringBuilder.append(textBlock.getText());
                stringBuilder.append("\n");

            }
            textView.setText(stringBuilder.toString());
        }
    }
}
